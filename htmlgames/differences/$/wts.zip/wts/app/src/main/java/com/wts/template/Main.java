package com.wts.template;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;

import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 *
 * @see //SystemUiHider
 */
public class Main extends Activity {
    WebView webView;
    String s = "";

	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.main);
        webView = (WebView)findViewById(R.id.fullscreen_content);
        webView.setWebViewClient(new MyWebViewClient(){

            public void onPageFinished(WebView view, String url) {
                try {
                        if (url.contains("?")) {
                            String[] ss = url.split("\\?");
                            s = ss[1];
                        } else {
                            s = "";
                        }
                } catch (Exception e) {
                    e.printStackTrace();
                    s = "";
                }
                //Toast.makeText(getBaseContext(), s, Toast.LENGTH_SHORT).show();
            }
        });

        try {
            FileInputStream fileIn=openFileInput("game.txt");
            InputStreamReader InputRead= new InputStreamReader(fileIn);

            char[] inputBuffer= new char[READ_BLOCK_SIZE];

            int charRead;

            while ((charRead=InputRead.read(inputBuffer))>0) {
                // char to string conversion
                String readString=String.copyValueOf(inputBuffer,0,charRead);
                s +=readString;
            }
            InputRead.close();
            //Toast.makeText(getBaseContext(), s,Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            e.printStackTrace();
        }

        webView.loadUrl("file:///android_asset/www/index.html?" + s);
        //you can also link to a website. Example:
        //webView.loadUrl("www.google.com");
        //I have included web permissions in the AndroidManifest.xml
        webView.setWebChromeClient(new WebChromeClient());
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setMediaPlaybackRequiresUserGesture(false);
        webSettings.setDomStorageEnabled(true);
        webSettings.setTextZoom(100);

    }

    @Override
    public void onBackPressed()
    {
        saveGame(s); // save url search value here
        //if(webView.canGoBack()) webView.goBack();
        super.onBackPressed();
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
    }

   static final int READ_BLOCK_SIZE = 2000; // 2K (2048 max)

    // write text to file
    public void saveGame(String params) {
        // add-write text into file
        try {
            FileOutputStream fileOut=openFileOutput("game.txt", MODE_PRIVATE);
            OutputStreamWriter outputWriter=new OutputStreamWriter(fileOut);
            outputWriter.write(params);
            outputWriter.close();

            //display file saved message
            Toast.makeText(getBaseContext(), "goo.gl/zI6A",
                    Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Read text from file
    public void loadGame() {
        //reading text from file
        try {
            FileInputStream fileIn=openFileInput("game.txt");
            InputStreamReader InputRead= new InputStreamReader(fileIn);

            char[] inputBuffer= new char[READ_BLOCK_SIZE];
            String s="";
            int charRead;

            while ((charRead=InputRead.read(inputBuffer))>0) {
                // char to string conversion
                String readString=String.copyValueOf(inputBuffer,0,charRead);
                s +=readString;
            }
            InputRead.close();
            //Toast.makeText(getBaseContext(), s,Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
